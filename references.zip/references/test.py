import pandas as pd


df = pd.DataFrame({'a': [1, 2, 3]})

print(df)

def decorate_func(func):

    def func1(*args, **kwargs):
        """AI is creating summary for func1

        Returns:
            [type]: [description]
        """
        print('this function has been decorated')

        return func(*args, **kwargs)
    return func1


@decorate_func
def eat(who, food):
    """AI is creating summary for eat

    Args:
        who ([str]): [person name]
        food ([srt]): [your food]

    Returns:
        [str]: [description]
    """
    print(who + food)
    print('i love eat')
    return who

who = 'super idol'
food = 'cho'
eat(who, food)

def test_test():
    assert 1 == 1